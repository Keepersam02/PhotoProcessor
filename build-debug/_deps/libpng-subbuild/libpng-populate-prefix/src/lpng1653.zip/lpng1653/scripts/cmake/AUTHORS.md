CMake Files, Lists and Scripts for the PNG Reference Library
============================================================

Author List
-----------

 * Alex Gaynor
 * Alexey Petruchik
 * Andreas Franek
 * Andrew Hundt
 * B. Scott Michel
 * Benjamin Buch
 * Bernd Kuhls
 * Cameron Cawley
 * Christian Ehrlicher
 * Christopher Sean Morrison
 * Claudio Bley
 * Clifford Yapp
 * Clinton Ingram
 * Cosmin Truta
 * Dan Rosser
 * David Callu
 * Eric Riff
 * Erik Scholz
 * Gianfranco Costamagna
 * Gleb Mazovetskiy
 * Glenn Randers-Pehrson
 * Gunther Nikl
 * Jeremy Maitin-Shepard
 * John Bowler
 * Jon Creighton
 * Joost Nieuwenhuijse
 * Kyle Bentley
 * Luis Caro Campos
 * Martin Storsjö
 * Owen Rudge
 * Philip Lowman
 * Roger Leigh
 * Roger Lowman
 * Sam Serrels
 * Simon Hausmann
 * Steve Robinson
 * Timothy Lyanguzov
 * Tyler Kropp
 * Vadim Barkov
 * Vicky Pfau
